import math
import pandas as pd
import networkx as nx
from sklearn.cluster import KMeans

import dash
from dash import dcc, html, dash_table
import dash_bootstrap_components as dbc
from dash.dependencies import Input, Output
import plotly.graph_objects as go

from simulation_backend import (
    calculate_energy_consumption,
    build_graph,
    rotate_cluster_heads,
    update_graph_edges,
    remove_depleted_nodes,
)

TOTAL_ROUNDS = 300
FAIL_THRESHOLD = 0.75
DATA_TEMPLATE = pd.read_csv("wsn_simulation_dataset.csv")

app = dash.Dash(
    __name__,
    external_stylesheets=[
        dbc.themes.LITERA,
        "https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap"
    ]
)

app.layout = html.Div(style={"padding":"20px","fontFamily":"Inter, sans-serif"}, children=[
    dbc.Row(dbc.Col(html.H2("📡 Wireless Sensor Network Simulation", className="text-center mb-4"), width=12)),

    dbc.Row([
        dbc.Col([
            html.Label("Optimization:", className="fw-semibold"),
            dcc.Dropdown(
                id="opt-toggle",
                options=[
                    {"label":"Without Optimization","value":False},
                    {"label":"With Optimization","value":True},
                ],
                value=False,
                clearable=False,
                style={"width":"250px"}
            )
        ], width="auto"),

        dbc.Col([
            html.Label("Speed (ms):", className="fw-semibold"),
            dcc.Slider(
                id="speed-slider",
                min=100, max=300, step=100, value=200,
                marks={i:str(i) for i in range(100,301,100)},
                tooltip={"placement":"bottom"}
            )
        ], width="auto"),

        dbc.Col(html.Div(id="round-display", className="fs-5 fw-bold text-primary"), width="auto")
    ], className="mb-4 align-items-center"),

    dbc.Card(dbc.CardBody(dcc.Graph(id="network-graph", style={"height":"600px"})), className="shadow-sm mb-4"),

    dbc.Card([
        dbc.CardHeader("Node Status Table"),
        dbc.CardBody(dash_table.DataTable(
            id="node-table",
            columns=[
                {"name":"Node_ID","id":"Node_ID"},
                {"name":"Role","id":"Role"},
                {"name":"Energy","id":"Energy"},
            ],
            style_table={"overflowY":"auto","height":"300px"},
            style_cell={"textAlign":"center","padding":"5px"}
        ))
    ], className="shadow-sm"),

    dcc.Interval(id="interval", interval=200, n_intervals=0, max_intervals=TOTAL_ROUNDS)
])

@app.callback(
    Output("interval","interval"),
    Input("speed-slider","value")
)
def update_speed(ms):
    return ms

@app.callback(
    Output("interval","n_intervals"),
    Input("opt-toggle","value")
)
def reset_on_toggle(_):
    return 0

@app.callback(
    Output("network-graph","figure"),
    Output("node-table","data"),
    Output("round-display","children"),
    Output("interval","disabled"),
    Input("interval","n_intervals"),
    Input("opt-toggle","value")
)
def update(n, use_opt):
    if n == 0 or use_opt != getattr(update, "prev_opt", None):
        update.DATA = DATA_TEMPLATE.copy()
        update.G = build_graph(update.DATA, use_opt)
        update.pos = nx.get_node_attributes(update.G, "pos")
        update.initial_count = len(update.pos)
        update.prev_opt = use_opt

    G, data = update.G, update.DATA
    data = remove_depleted_nodes(G, data)
    if use_opt:
        rotate_cluster_heads(data, G)
    update_graph_edges(G, data, use_opt)

    for node in list(G.nodes):
        role = G.nodes[node]["role"]
        if role == "Normal":
            tgt = next((nbr for nbr in G.neighbors(node) if G.nodes[nbr]["role"] in ["Cluster Head","Sink"]), None)
            if tgt:
                G.nodes[node]["energy"] -= calculate_energy_consumption(G.nodes[node], G.nodes[tgt])
        elif role == "Cluster Head":
            sink = next((nbr for nbr in G.neighbors(node) if G.nodes[nbr]["role"]=="Sink"), None)
            if sink:
                G.nodes[node]["energy"] -= calculate_energy_consumption(G.nodes[node], G.nodes[sink])
        G.nodes[node]["energy"] = max(G.nodes[node]["energy"], 0)

    edge_x, edge_y = [], []
    for u, v in G.edges():
        x0, y0 = update.pos[u]; x1, y1 = update.pos[v]
        edge_x += [x0, x1, None]; edge_y += [y0, y1, None]

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=edge_x, y=edge_y, mode="lines"))
    # Colored nodes + top‑center text
    fig.add_trace(go.Scatter(
        x=[update.pos[n][0] for n in G.nodes()],
        y=[update.pos[n][1] for n in G.nodes()],
        mode="markers+text",
        marker=dict(
            size=[max(G.nodes[n]["energy"],1)*0.3 for n in G.nodes()],
            color=[
                "yellow" if G.nodes[n]["role"]=="Sink" else
                "blue"   if G.nodes[n]["role"]=="Cluster Head" else
                "green"  if G.nodes[n]["energy"]>30 else
                "red"
                for n in G.nodes()
            ]
        ),
        text=[f"{n}<br>∞" if G.nodes[n]["role"]=="Sink"
            else f"{n}<br>{int((G.nodes[n]['energy']/100)*100)}%"
            for n in G.nodes()],
        textposition="top center"
    ))

    # Centered antenna icon
    fig.add_trace(go.Scatter(
        x=[update.pos[n][0] for n in G.nodes()],
        y=[update.pos[n][1] for n in G.nodes()],
        mode="text",
        text=["📡"] * len(G.nodes()),
        textposition="middle center",
        textfont=dict(
            size=[
                12 if G.nodes[n]["role"] == "Sink" 
                else max(int(max(G.nodes[n]["energy"], 1) * 0.3), 1)
                for n in G.nodes()
            ]
        )
    ))

    fig.update_layout(xaxis=dict(visible=False), yaxis=dict(visible=False))

    table = [{"Node_ID":n, "Role":G.nodes[n]["role"], "Energy":"∞" if G.nodes[n]["role"]=="Sink" else round(G.nodes[n]["energy"],2)} for n in G.nodes()]

    alive = len(G.nodes())
    failed = alive == 0 or alive < update.initial_count * FAIL_THRESHOLD
    reason = "All nodes depleted" if alive == 0 else "25% nodes lost"

    if failed:
        return fig, table, f"❌ Network failed at round {n} ({reason})", True

    return fig, table, f"Round: {n} / {TOTAL_ROUNDS}", False

if __name__ == "__main__":
    app.run(debug=True)
