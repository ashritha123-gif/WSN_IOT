import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from sklearn.cluster import DBSCAN
import math


def calculate_energy_consumption(node, target, amplification_factor=0.0001, base_energy=0.7):
    """Calculate energy consumed based on the distance to the target."""
    x1, y1 = node["pos"]
    x2, y2 = target["pos"]
    distance = math.sqrt((x1 - x2)**2 + (y1 - y2)**2)
    return base_energy + amplification_factor * (distance**2)


def build_graph(data, use_optimization=False, num_clusters=12):
    """Build a graph from the given data."""
    G = nx.Graph()

    # Add nodes with their attributes
    for _, row in data.iterrows():
        G.add_node(
            row["Node_ID"],
            pos=(row["X_Pos"], row["Y_Pos"]),
            energy=row["Energy"],
            role=row["Role"],
        )

    if use_optimization:
        # Apply clustering to identify cluster heads
        positions = data[["X_Pos", "Y_Pos"]].values
        labels = DBSCAN(eps=9, min_samples=1).fit_predict(positions)
        data["Cluster"] = labels

        # Assign cluster heads dynamically (based on maximum energy)
        for cluster_id in sorted(set(data["Cluster"])):
            if cluster_id == -1:
                continue  # Skip noise points
            cluster_nodes = data[data["Cluster"] == cluster_id]["Node_ID"].values
            if len(cluster_nodes) == 0:
                continue
            cluster_head = max(cluster_nodes, key=lambda node: G.nodes[node]["energy"])
            G.nodes[cluster_head]["role"] = "Cluster Head"

            # Connect cluster members to cluster head
            for node_id in cluster_nodes:
                if node_id != cluster_head:
                    G.add_edge(cluster_head, node_id)

        # Connect all cluster heads to the sink
        sink_node = data[data["Role"] == "Sink"]["Node_ID"].values[0]
        for cluster_id in sorted(set(data["Cluster"])):
            if cluster_id == -1:
                continue  # Skip noise points
            cluster_nodes = data[data["Cluster"] == cluster_id]["Node_ID"].values
            if len(cluster_nodes) == 0:
                continue
            cluster_head = max(cluster_nodes, key=lambda node: G.nodes[node]["energy"])
            G.add_edge(cluster_head, sink_node)


    else:
        # Without optimization, connect all nodes directly to the sink
        sink_node = data[data["Role"] == "Sink"]["Node_ID"].values[0]
        for node_id in G.nodes:
            if node_id != sink_node:
                G.add_edge(node_id, sink_node)

    return G


def rotate_cluster_heads(data, G, random_probability=0.3):
    """Dynamically rotate cluster heads for each cluster based on multiple conditions."""
    if "Cluster" in data.columns:
        num_clusters = data["Cluster"].nunique()

        for cluster_id in range(num_clusters):
            # Get all nodes in the current cluster
            cluster_nodes = [
                node
                for node in data[data["Cluster"] == cluster_id]["Node_ID"].values
                if node in G.nodes
            ]

            # Reset all nodes in the cluster to "Normal" first
            for node in cluster_nodes:
                if G.nodes[node]["role"] != "Sink":
                    G.nodes[node]["role"] = "Normal"

            # Select a new cluster head based on maximum energy
            candidates = [
                node
                for node in cluster_nodes
                if G.nodes[node]["energy"] > 0 and G.nodes[node]["role"] != "Sink"
            ]

            if candidates:
                # Select the node with the maximum energy as the new cluster head
                new_head = max(candidates, key=lambda node: G.nodes[node]["energy"])
                G.nodes[new_head]["role"] = "Cluster Head"


def update_graph_edges(G, data, use_optimization=False):
    """Update graph edges dynamically based on node roles and connections."""
    sink_node = next((n for n,a in G.nodes(data=True) if a["role"]=="Sink"), None)
    if sink_node is None:
        sink_row = data[data["Role"]=="Sink"].iloc[0]
        G.add_node(int(sink_row["Node_ID"]), pos=(sink_row["X_Pos"], sink_row["Y_Pos"]), energy=float("inf"), role="Sink")
        sink_node = int(sink_row["Node_ID"])

    G.clear_edges()

    if use_optimization and "Cluster" in data.columns:
        for cluster_id in data["Cluster"].unique():
            # Only include nodes still in G
            cluster_nodes = [int(n) for n in data[data["Cluster"]==cluster_id]["Node_ID"].values if int(n) in G.nodes]
            cluster_head = next((n for n in cluster_nodes if G.nodes[n]["role"]=="Cluster Head"), None)
            if cluster_head:
                for member in cluster_nodes:
                    if member != cluster_head:
                        G.add_edge(cluster_head, member)

        for n, attr in G.nodes(data=True):
            if attr["role"]=="Cluster Head":
                G.add_edge(n, sink_node)

    else:
        for node in list(G.nodes):
            if node != sink_node:
                G.add_edge(node, sink_node)


def remove_depleted_nodes(G, data):
    """Remove depleted nodes from the graph and data."""
    depleted_nodes = [
        node
        for node, attr in G.nodes(data=True)
        if attr["energy"] <= 0 and attr["role"] != "Sink"
    ]
    G.remove_nodes_from(depleted_nodes)
    return data[~data["Node_ID"].isin(depleted_nodes)]


def simulate_network(data, rounds, use_optimization=False, ax=None, title="WSN Simulation"):
    """Simulate the wireless sensor network and visualize it."""
    num_clusters = 12 if use_optimization else None
    G = build_graph(data, use_optimization, num_clusters)
    pos = nx.get_node_attributes(G, "pos")

    if ax is None:
        fig, ax = plt.subplots()

    def update(frame):
        nonlocal G, data

        # Stop if all nodes are depleted
        if len(G.nodes) == 0:
            print(f"{title}: All nodes depleted by round {frame}.")
            ani.event_source.stop()
            return

        # Remove depleted nodes from graph and data
        data = remove_depleted_nodes(G, data)

        # Stop if 25% of the nodes are lost
        if len(G.nodes) < len(pos) * 0.75:
            print(f"{title}: Network failed after {frame} rounds (25% node loss).")
            ani.event_source.stop()
            return

        # Update cluster heads and edges if optimization is enabled
        if use_optimization:
            rotate_cluster_heads(data, G)
        update_graph_edges(G, data, use_optimization)

        for node in G.nodes:
            if G.nodes[node]["role"] == "Normal":
                # Normal nodes send data to their cluster head or sink
                target = next(
                    (neighbor for neighbor in G.neighbors(node) if G.nodes[neighbor]["role"] in ["Cluster Head", "Sink"]),
                    None
                )
                if target:
                    G.nodes[node]["energy"] -= calculate_energy_consumption(G.nodes[node], G.nodes[target])
                    G.nodes[node]["energy"] = max(G.nodes[node]["energy"], 0)

            # …cluster head block…
                    G.nodes[node]["energy"] -= calculate_energy_consumption(G.nodes[node], G.nodes[sink])
                    G.nodes[node]["energy"] = max(G.nodes[node]["energy"], 0)
            elif G.nodes[node]["role"] == "Cluster Head":
                # Cluster heads send data to the sink
                sink = next((neighbor for neighbor in G.neighbors(node) if G.nodes[neighbor]["role"] == "Sink"), None)
                if sink:
                    G.nodes[node]["energy"] -= calculate_energy_consumption(G.nodes[node], G.nodes[sink])

        # Clear and redraw
        ax.clear()
        if len(G.nodes) > 0:
            node_colors = []
            labels = {}
            for node in G.nodes:
                if G.nodes[node]["role"] == "Sink":
                    energy_percentage = "∞"  # Infinite energy for the sink node
                    node_colors.append("yellow")  # Sink in yellow
                else:
                    energy_percentage = int((G.nodes[node]["energy"] / 100) * 100)
                    if G.nodes[node]["role"] == "Cluster Head":
                        node_colors.append("blue")  # Cluster heads in blue
                    else:
                        node_colors.append("green" if G.nodes[node]["energy"] > 30 else "red")

                # Two-line label
                labels[node] = f"{node}\n[{energy_percentage}%]"

            nx.draw(
                G,
                pos,
                ax=ax,
                node_size=[max(G.nodes[node]["energy"], 1) * 15 for node in G.nodes],
                node_color=node_colors,
                with_labels=True,
                labels=labels,
                font_size=6,  # Adjust font size as needed
            )
            ax.set_title(f"{title} - Round {frame}/{rounds}")

    ani = FuncAnimation(plt.gcf(), update, frames=rounds, repeat=False)
    plt.show()


# Example Usage for Testing
if __name__ == "__main__":
    data = pd.read_csv("wsn_simulation_dataset.csv")
    print("Simulating without optimization...")
    simulate_network(data, rounds=200, use_optimization=False, title="Without Optimization")

    print("Simulating with optimization...")
    simulate_network(data, rounds=200, use_optimization=True, title="With Optimization")
