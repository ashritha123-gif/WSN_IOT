https://www.python.org/ftp/python/3.11.8/python-3.11.8-amd64.exe

python -m venv .venv

.venv\Scripts\activate

pip install -r requirements.txt

python run_simulation_app.py