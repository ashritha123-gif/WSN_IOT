import pandas as pd

def load_data(path="wsn_simulation_dataset.csv"):
    return pd.read_csv(path)
